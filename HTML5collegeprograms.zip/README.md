## html5 sies college projects (11th B)
#### made by Denzven Vadakkan Ignatius
#### I DO NOT OWN THE CODE MYSELF IT HAS BEEN REFERRED AND WRITTEN FROM MY FYJC COLLEGE TEXTBOOK
---
#### run the code with --->

Repl ---> [![Run on Repl.it](https://repl.it/badge/github/denzven/HTML5_college_programs)](https://repl.it/github/denzven/HTML5_college_programs)

---
